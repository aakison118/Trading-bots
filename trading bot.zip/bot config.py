from apscheduler.schedulers.blocking import BlockingScheduler
from botv2 import tj_EMAS
from bot import trading_job

scheduler = BlockingScheduler()
    # opening message
scheduler.add_job(print,args=["\n######################### START #########################"],
                  trigger="cron",day_of_week="mon-sun",hour="00-23",minute="00,15,30,45",second="0")
    # bot V2
scheduler.add_job(tj_EMAS,args=["usdjpy",1000,0.01],trigger="cron",day_of_week="mon-sun",hour="00-23",minute="00,15,30,45",second="1")
scheduler.add_job(tj_EMAS,args=["audusd",1000,0.0001],trigger="cron",day_of_week="mon-sun",hour="00-23",minute="00,15,30,45",second="2")
scheduler.add_job(tj_EMAS,args=["nzdusd",1000,0.0001],trigger="cron",day_of_week="mon-sun",hour="00-23",minute="00,15,30,45",second="3")
    # og bot
scheduler.add_job(trading_job,"cron",day_of_week="mon-sun",hour="00-23",minute="0,5,10,15,20,25,30,35,40,45,50,55",second="4")
    # closing message
scheduler.add_job(print,args=["########################## END ##########################\n"],
                  trigger="cron",day_of_week="mon-sun",hour="00-23",minute="00,15,30,45",second="5")
scheduler.start()