import pandas as pd
from oandapyV20 import API
import oandapyV20.endpoints.orders as orders
from oanda_candles import Pair,Gran,CandleClient
from oandapyV20.contrib.requests import MarketOrderRequest,TrailingStopLossDetails,TakeProfitDetails,StopLossDetails

####### improved trading strategy (EMAS) ########

"""##### Getting trade signals #####"""
    
    # define signal functions
def signal_generator(df):
    # create df of EMAs in 5, 20 and 50 periods
    close = df["Close"].to_frame()
    close["EWMA5"] = close["Close"].ewm(span=5).mean()
    close["EWMA20"] = close["Close"].ewm(span=20).mean()
    close["EWMA50"] = close["Close"].ewm(span=50).mean()
    # taking current and prev. period EMAs
    ema5,lastema5 = close["EWMA5"].iloc[-1],close["EWMA5"].iloc[-2]
    ema20,lastema20 = close["EWMA20"].iloc[-1],close["EWMA20"].iloc[-2]
    ema50,closing = close["EWMA50"].iloc[-1],close["Close"].iloc[-1]
    
    # selling signal
    if (lastema5>lastema20 and ema5<ema20 and
        closing<ema50 and ema5<ema50 and ema20<ema50):
        return 1
    
    # buying signal
    elif (lastema5<lastema20 and ema5>ema20 and
        closing>ema50 and ema5>ema50 and ema20>ema50):
        return 2
    
    else: # no signal
        return 0


def tj_EMAS(curr,trade_size,pip_value):
      
    access_token = "APIKey"
    accountID = "ID"
    curr = str(curr)
    
    print(f"EMS trading: {str(curr[:len(curr)//2] + "/" + curr[len(curr)//2:]).upper()}")
    
    """##### Grabbing candle data #####"""
    
    def get_candles(n): # function grabs live candles for GBP/USD
        client = CandleClient(access_token,real=False)
        collector = client.get_collector(Pair(curr),Gran.M15)
        candles = collector.grab(n)
        return candles
    
    candles = get_candles(50) # grab last 50 candles
    # list with candle data
    dfstream = pd.DataFrame(columns=["Open","Close","High","Low"])
    # fill columns in df with data
    i = 0
    for candle in candles: 
        dfstream.loc[i,["Open"]] = float(str(candle.bid.o))
        dfstream.loc[i,["Close"]] = float(str(candle.bid.c))
        dfstream.loc[i,["High"]] = float(str(candle.bid.h))
        dfstream.loc[i,["Low"]] = float(str(candle.bid.l))
        i += 1 
    # ensuring all columns are floats in the dataframe
    dfstream["Open"] = dfstream["Open"].astype(float)
    dfstream["Close"] = dfstream["Close"].astype(float)
    dfstream["High"] = dfstream["High"].astype(float)
    dfstream["Low"] = dfstream["Low"].astype(float)
    

    # getting trade signal for data from signal_generator()
    signal = signal_generator(dfstream)

    """##### Setting SL and TP #####"""
    
    client = API(access_token)

    # setting SL, TSL and TP
    SLBuy = float(str(candle.bid.o)) - 10*pip_value
    SLSell = float(str(candle.bid.o)) + 10*pip_value
    
    TSLBuy = 2*10*pip_value
    TSLSell = 2*10*pip_value
    
    TPBuy = float(str(candle.bid.o)) + 2*10*pip_value
    TPSell = float(str(candle.bid.o)) - 2*10*pip_value
    
    # print(dfstream.iloc[:-1,:])
    print(f"TPBuy: {TPBuy}, SLBuy: {SLBuy}, TPSell: {TPSell}, SLSell: {SLSell}")
    
    """##### Executing orders #####"""
    
    # Sell
    tradingcur = str(curr[:len(curr)//2] + "_" + curr[len(curr)//2:]).upper()
    if signal == 1:
        mor = MarketOrderRequest(instrument=tradingcur,units=-1*trade_size,
                                takeProfitOnFill=TakeProfitDetails(price=TPSell).data,
                                trailingStopLossOnFill=TrailingStopLossDetails(distance=TSLSell).data,
                                stopLossOnFill=StopLossDetails(price=SLSell).data)
        r = orders.OrderCreate(accountID,data=mor.data)
        rv = client.request(r)
        print(rv)
    # Buy
    elif signal == 2:
        mor = MarketOrderRequest(instrument=tradingcur,units=trade_size,
                                takeProfitOnFill=TakeProfitDetails(price=TPBuy).data,
                                trailingStopLossOnFill=TrailingStopLossDetails(distance=TSLBuy).data,
                                stopLossOnFill=StopLossDetails(price=SLBuy).data)
        r = orders.OrderCreate(accountID,data=mor.data)
        rv = client.request(r)
        print(rv)
    # no trade
    else:
        print("no trade\n")
        pass